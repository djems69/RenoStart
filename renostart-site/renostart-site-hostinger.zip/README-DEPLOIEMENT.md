# 🚀 Déploiement RenoStart sur Hostinger

## 📋 Prérequis
- Compte Hostinger avec hébergement web
- Accès FTP ou File Manager
- Domaine configuré (optionnel)

## 📁 Structure des fichiers à uploader

```
📦 Dossier à uploader sur Hostinger
├── 📄 index.html (page d'accueil)
├── 📄 404.html (page d'erreur)
├── 📄 contact-process.php (script de traitement du formulaire)
├── 📄 .htaccess (configuration serveur)
├── 📁 _next/ (fichiers statiques Next.js)
├── 📁 a-propos/ (page à propos)
├── 📁 contact/ (page contact)
├── 📁 formations/ (page formations)
├── 📁 404/ (page d'erreur)
└── 📄 [autres fichiers statiques]
```

## 🔧 Étapes de déploiement

### 1. **Accéder à votre hébergement Hostinger**
- Connectez-vous à votre panneau Hostinger
- Allez dans "File Manager" ou utilisez un client FTP

### 2. **Upload des fichiers**
- Naviguez vers le dossier `public_html` (ou `www`)
- Supprimez tous les fichiers existants (sauf si vous avez d'autres sites)
- Uploadez TOUS les fichiers du dossier `out/` dans `public_html`

### 3. **Configuration du domaine**
- Si vous avez un domaine personnalisé, configurez-le dans Hostinger
- Sinon, utilisez l'URL fournie par Hostinger (ex: `votre-site.hostinger.com`)

### 4. **Test du formulaire**
- Allez sur votre site : `https://votre-domaine.com/contact`
- Testez le formulaire de contact
- Vérifiez que l'email arrive à `gestion@renostart-conseil.fr`

## ⚙️ Configuration PHP

### **Email de destination**
Pour changer l'adresse email de réception, modifiez le fichier `contact-process.php` :

```php
$to_email = "votre-email@exemple.com"; // Changez cette ligne
```

### **Configuration SMTP (optionnel)**
Si les emails ne partent pas, contactez le support Hostinger pour activer SMTP.

## 🔒 Sécurité

Le site inclut :
- ✅ Protection XSS
- ✅ Validation des données
- ✅ Protection anti-spam
- ✅ Headers de sécurité
- ✅ Compression Gzip

## 📞 Support

En cas de problème :
1. Vérifiez que tous les fichiers sont uploadés
2. Testez le formulaire de contact
3. Contactez le support Hostinger si nécessaire

## 🌐 URLs du site

- **Accueil** : `https://votre-domaine.com/`
- **À propos** : `https://votre-domaine.com/a-propos`
- **Contact** : `https://votre-domaine.com/contact`
- **Formations** : `https://votre-domaine.com/formations`

---

**RenoStart Conseil** - Spécialiste BTP 🏗️
